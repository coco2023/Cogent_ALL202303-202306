package com.cogent.Batch65_SpringBootV06;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Batch65SpringBootV06ApplicationTests {

	@Test
	void contextLoads() {
	}

}
