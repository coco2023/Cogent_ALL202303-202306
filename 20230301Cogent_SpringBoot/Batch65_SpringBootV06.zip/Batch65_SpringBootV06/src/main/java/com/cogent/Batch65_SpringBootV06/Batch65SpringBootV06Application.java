package com.cogent.Batch65_SpringBootV06;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Batch65SpringBootV06Application {

	public static void main(String[] args) {
		SpringApplication.run(Batch65SpringBootV06Application.class, args);
	}

}
