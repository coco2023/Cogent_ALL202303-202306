package com.cogent.Batch65_TripHW;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Batch65TripHwApplication {

	public static void main(String[] args) {
		SpringApplication.run(Batch65TripHwApplication.class, args);
	}

}
