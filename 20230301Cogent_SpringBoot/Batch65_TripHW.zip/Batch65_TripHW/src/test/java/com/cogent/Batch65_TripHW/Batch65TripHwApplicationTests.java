package com.cogent.Batch65_TripHW;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Batch65TripHwApplicationTests {

	@Test
	void contextLoads() {
	}

}
