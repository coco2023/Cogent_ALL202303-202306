package com.cogent.Batch65_SpringBootV05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Batch65SpringBootV05Application {

	public static void main(String[] args) {
		SpringApplication.run(Batch65SpringBootV05Application.class, args);
	}

}
