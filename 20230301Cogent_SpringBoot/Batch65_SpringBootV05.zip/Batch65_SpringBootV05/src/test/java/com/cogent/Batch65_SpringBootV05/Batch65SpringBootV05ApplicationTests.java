package com.cogent.Batch65_SpringBootV05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Batch65SpringBootV05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
