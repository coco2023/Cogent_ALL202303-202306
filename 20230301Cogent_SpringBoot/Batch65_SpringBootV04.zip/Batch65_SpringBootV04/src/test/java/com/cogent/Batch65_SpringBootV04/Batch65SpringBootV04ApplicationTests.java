package com.cogent.Batch65_SpringBootV04;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Batch65SpringBootV04ApplicationTests {

	@Test
	void contextLoads() {
	}

}
