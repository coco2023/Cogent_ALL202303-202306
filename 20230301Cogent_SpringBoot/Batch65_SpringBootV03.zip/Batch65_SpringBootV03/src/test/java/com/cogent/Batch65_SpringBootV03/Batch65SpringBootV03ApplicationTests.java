package com.cogent.Batch65_SpringBootV03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Batch65SpringBootV03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
