export interface Meal {
  thumb: string;
  name: string;
  instructions: string;
  youtubeLink: string;
  ingredients?: string[];
}
