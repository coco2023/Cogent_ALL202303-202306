export class Customer {
    customerId:any;
    username: any;
    fullname: any;
    password: any;
    phone:any;
    identityID:any;
    secretQuestion:any;
    secretAnswer:any;
}