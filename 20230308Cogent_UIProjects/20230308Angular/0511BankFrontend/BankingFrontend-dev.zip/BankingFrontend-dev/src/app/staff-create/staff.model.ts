export interface Staff {
    id?: number;
    staffFullName: string;
    staffUserName: string;
    staffPassword: string;
}
  