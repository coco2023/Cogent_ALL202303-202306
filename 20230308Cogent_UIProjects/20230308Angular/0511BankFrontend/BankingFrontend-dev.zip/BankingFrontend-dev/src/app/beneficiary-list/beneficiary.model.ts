export interface Beneficiary {
    fromCustomer: Number;
    beneficiaryAcNo: Number;
    beneficiaryAddedDate: Date;
    approved: String;
  }
  