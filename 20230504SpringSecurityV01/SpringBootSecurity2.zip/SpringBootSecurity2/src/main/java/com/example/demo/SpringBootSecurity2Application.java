package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSecurity2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSecurity2Application.class, args);
	}

}
