package com.cogent.Batch65_SpringSecurityV01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Batch65SpringSecurityV01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
